<!-- Add -->
<div class="modal fade" id="addDiagnosa">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Cari Diagnosa </h5>
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                    <div class="form-group">
                       
                        <div class="row">
                            <table class="display white-border table-responsive-sm"
                                style="width: 100%"
                             id="icd-table">
                                <thead>
                                    <tr>
                                        <th style="width: 5%">#</th>
                                        <th style="width: 15%">Kode</th>
                                        <th style="width: 80%">Nama</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                       
                       
                    </div>
                    
                   
                </form>
            </div>
        </div>
    </div>
</div>
